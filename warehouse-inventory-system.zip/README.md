# Warehouse Inventory Management System (WIMS)

A lightweight Warehouse Inventory Management System developed for the Second Year Engineering **Internet Programming (IP) Lab (Java Backend)** formative assessment.

---

## 📌 Project Overview
This project provides real-time tracking of warehouse inventory, storage zones, low-stock reorder thresholds, and inward/outward material movement audit logs.

### Key Features:
- **Interactive Dashboard:** Live counts of total items, units in storage, critical low-stock alerts, and total asset valuation.
- **Stock Inventory Catalog:** Item details including SKU, Category, Assigned Storage Rack, Stock Count, and Minimum Reorder Level.
- **Dynamic Threshold Alerts:** Real-time visual status badges (*Optimal*, *Low Stock*, *Critical Low*).
- **Stock Movements (Inward/Outward):** Complete audit trail tracking receiving shipments and dispatch orders with handler names and PO reference numbers.
- **Storage Rack & Supplier Directory:** Multi-zone warehouse location tracking and supplier contact records.

---

## 🛠️ Tech Stack
- **Frontend:** HTML5, CSS3, Vanilla JavaScript (Single-page, responsive, no external dependencies).
- **Database:** MySQL 8.0 (5 relational tables in 3NF with Primary and Foreign Keys).
- **Backend:** Java (JDBC with `DriverManager`, `PreparedStatement`, and DAO pattern).

---

## 📁 Project Structure
```text
warehouse-inventory-system/
│
├── index.html                   # Complete Frontend Dashboard UI
├── warehouse_inventory_db.sql   # MySQL Database Schema & Sample Records
├── Project_Plan.md              # Formative Assessment Architecture & Plan
├── README.md                    # Project Documentation
│
└── backend_src/                 # Java Backend Architecture (JDBC & DAO)
    ├── DBConnection.java        # JDBC Database Connection Manager
    ├── Product.java             # Product Model / POJO
    └── ProductDAO.java          # Product Data Access Object (CRUD Operations)
```

---

## 🗄️ Database Setup (MySQL)
1. Open **MySQL Workbench** or your terminal:
   ```bash
   mysql -u root -p
   ```
2. Run or import `warehouse_inventory_db.sql`:
   ```sql
   SOURCE path/to/warehouse_inventory_db.sql;
   ```
3. Verify the setup:
   ```sql
   USE warehouse_db;
   SHOW TABLES;
   SELECT * FROM products;
   ```

---

## 🚀 Running the Frontend
Simply double-click `index.html` to open it directly in any web browser (Chrome, Edge, Firefox), or use the VS Code **Live Server** extension.

---

## 👨‍💻 Academic Information
- **Course:** Internet Programming (IP) Lab — Java Backend
- **Year:** Second Year Engineering (SE)
- **Database:** MySQL 8.0
